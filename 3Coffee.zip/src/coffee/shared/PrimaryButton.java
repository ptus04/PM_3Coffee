package coffee.shared;

import coffee.constant.Colors;

public class PrimaryButton extends RoundedButton {

	private static final long serialVersionUID = 8626192094139620401L;

	public PrimaryButton(String label) {
		super(label, Colors.PRIMARY);
	}

	public PrimaryButton(String label, String iconPath) {
		super(label, iconPath, Colors.PRIMARY);
	}

}
